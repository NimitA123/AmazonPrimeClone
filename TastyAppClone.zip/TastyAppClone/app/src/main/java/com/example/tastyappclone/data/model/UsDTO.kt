package com.example.tastyappclone.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class UsDTO(

	@field:SerializedName("amount")
	val amount: Any? = null,

	@field:SerializedName("unitShort")
	val unitShort: String? = null,

	@field:SerializedName("unitLong")
	val unitLong: String? = null
)