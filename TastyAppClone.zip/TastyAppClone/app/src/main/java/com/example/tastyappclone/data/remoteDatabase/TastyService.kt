package com.example.tastyappclone.data.remoteDatabase

import com.example.tastyappclone.data.model.ResponseDTO
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface TastyService{
    @GET("/recipes/random")
    suspend fun getDetails(
     @Query("apiKey") apiKey:String,
     @Query("number") number:Int,
     @Query("tags") tags:String
    ) : Response<ResponseDTO>
}
