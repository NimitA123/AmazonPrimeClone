package com.example.tastyappclone.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.tastyappclone.data.model.ResponseDTO
import kotlinx.android.synthetic.main.tasty_item_layout.view.*

class TastyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    fun setData(data: ResponseDTO) {
        if(data!= null) {
          //  Log.d("Nimit", )
           // itemView.textView.text =data.meals.toString()
        }
        else{
          //  itemView.textView.text = "Nimit"
        }

    }
}