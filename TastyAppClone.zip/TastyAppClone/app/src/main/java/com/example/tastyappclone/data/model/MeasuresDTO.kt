package com.example.tastyappclone.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class MeasuresDTO(

	@field:SerializedName("us")
	val us: UsDTO? = null,

	@field:SerializedName("metric")
	val metric: MetricDTO? = null
)