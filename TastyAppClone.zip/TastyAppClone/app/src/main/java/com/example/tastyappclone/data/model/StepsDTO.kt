package com.example.tastyappclone.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class StepsDTO(

	@field:SerializedName("number")
	val number: Int? = null,

	@field:SerializedName("step")
	val step: String? = null,

	@field:SerializedName("ingredients")
	val ingredients: List<IngredientsDTO?>? = null,

	@field:SerializedName("equipment")
	val equipment: List<EquipmentDTO?>? = null
)