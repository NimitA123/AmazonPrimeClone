package com.example.tastyappclone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer

import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tastyappclone.adapter.TastyAdapter
import com.example.tastyappclone.data.model.ResponseDTO
import com.example.tastyappclone.data.remoteDatabase.Network
import com.example.tastyappclone.data.remoteDatabase.TastyService

import com.example.tastyappclone.databinding.ActivityMainBinding
import com.example.tastyappclone.reposirity.TastyReposirity

import com.example.tastyappclone.viewModel.MainTastyAppViewModel
import com.example.tastyappclone.viewModel.TastyAppViewModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private var arrayList = arrayListOf<ResponseDTO>()

    private lateinit var tastyAppViewModel1: TastyAppViewModel
    private lateinit var tastyResposirity: TastyReposirity

    private lateinit var adapter:TastyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
      //  println("Nimit")
     //   Log.d("Nimit", "Mausam")
        buildData()
    }
   //This function is responsible for fetching data from the ViewModel
    private fun buildData() {
      val  apiService = Network.getResponse().create(TastyService::class.java)
      tastyResposirity = TastyReposirity(apiService)
      tastyAppViewModel1= ViewModelProvider(this,  MainTastyAppViewModel(tastyResposirity)).get(TastyAppViewModel::class.java)
      tastyAppViewModel1.tastyData.observe(this, Observer {
    //      println("Nimit")
          Log.d("Nimit", it.toString())
         arrayList = it as ArrayList<ResponseDTO>
          if(arrayList!= null){
             setAdapter()
          }else{
              Log.d("Nimit", "Mausam")
          }

      })


    }
   //This function is responsible for setting data into the adapter class
    private fun setAdapter() {
        adapter = TastyAdapter(arrayList)
        val linearLayoutManager = LinearLayoutManager(this)
        rvRecyclerView.adapter = adapter
        rvRecyclerView.layoutManager = linearLayoutManager

    }
}