package com.example.tastyappclone.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tastyappclone.data.model.ResponseDTO
import com.example.tastyappclone.reposirity.TastyReposirity

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TastyAppViewModel(private val tastyResposirity: TastyReposirity) : ViewModel(){

      fun getApi(){
          viewModelScope.launch(Dispatchers.IO) {
            tastyResposirity.getRetrofit()
          }
      }
    val tastyData:LiveData<ResponseDTO>
    get() = tastyResposirity.liveData

}