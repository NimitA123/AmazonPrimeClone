package com.example.tastyappclone.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class IngredientsDTO(

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("localizedName")
	val localizedName: String? = null,

	@field:SerializedName("image")
	val image: String? = null
)