package com.example.tastyappclone.reposirity

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.tastyappclone.data.model.ResponseDTO
import com.example.tastyappclone.data.remoteDatabase.TastyService

class TastyReposirity(private val apiService: TastyService) {
    var apiData = MutableLiveData<ResponseDTO>()
    val liveData:LiveData<ResponseDTO>
    get() = apiData
    suspend fun getRetrofit(){
        val response = apiService.getDetails("70d7232d79bb45e7b6ec09c90aaa1dc4", 1, "dessert")
        if(response.body()!= null){
            apiData.postValue(response.body())
        }
    }
}
